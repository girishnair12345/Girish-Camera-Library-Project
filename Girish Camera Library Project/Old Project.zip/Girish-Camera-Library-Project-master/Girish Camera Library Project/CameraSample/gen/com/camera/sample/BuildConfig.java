/** Automatically generated file. DO NOT MODIFY */
package com.camera.sample;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}